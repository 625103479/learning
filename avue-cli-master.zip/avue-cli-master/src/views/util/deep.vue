<template>
  <basic-container>多级菜单</basic-container>
</template>

<script>
export default {
  data () {
    return {};
  },
  computed: {},
  created () { },
  methods: {}
};
</script>

<style scoped="scoped" lang="scss">
</style>
