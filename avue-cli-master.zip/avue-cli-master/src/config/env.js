let baseUrl = import.meta.env.VITE_BASE_URL;
export { baseUrl }